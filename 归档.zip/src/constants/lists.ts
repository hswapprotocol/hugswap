// the Default Default token list lives here
export const DEFAULT_TOKEN_LIST_URL = `${location.origin}/tokenlist.json?v=2`
export const DEFAULT_LIST_OF_LISTS: string[] = [
  DEFAULT_TOKEN_LIST_URL,
]
