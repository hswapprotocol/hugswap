import { UNISWAP_GRANTS } from './uniswap_grants'

// Proposals are 0-indexed
export const PRELOADED_PROPOSALS = new Map([[2, UNISWAP_GRANTS]])
